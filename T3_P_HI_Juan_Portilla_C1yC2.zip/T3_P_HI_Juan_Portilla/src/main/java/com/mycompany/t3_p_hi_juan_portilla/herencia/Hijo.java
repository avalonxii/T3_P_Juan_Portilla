/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.t3_p_hi_juan_portilla.herencia;

/**
 *
 * @author 34632
 */

//clase que hereda
public class Hijo extends Padre{ // se usa exteds(oalabra reservada) para especificar de quien se hereda
   
    int edad; //atributo propio de la clase hijo (no la tiene padre)

    public Hijo(int edad, String nombre, String Apellidos) { // si no tiene constructor da error
        super(nombre, Apellidos); //atributos heredados de Padre
        this.edad = edad;
    }  

    @Override //siempre que hay sobreescrituar aparece esta etiqueta
    public void saludar() {
        System.out.println("hola soy HIJO"); 
    }
    
    //sobrecarga del metodo saludar añadiendole dos paramatros (por lo que cambia la firma)
    public void saludar(String saludo, int edad){
        System.out.println("Hola buenas soy "+saludo+" y  tengo "+edad+"años");
    }  
    
    //sobreescritura cambiando el orden
    public void saludar(int edad, String saludo){
        System.out.println("Cambiando el orden");
    } 
    
}
