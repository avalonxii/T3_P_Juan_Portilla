/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.t3_p_hi_juan_portilla.dataStructure;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

/**
 *
 * @author 34632
 */
public class Principal {
    public static void main(String[] args) {
        
        /*/Listas / List
        List<String> lista = new ArrayList<String>();
        //La lista administra objetos de la clase String, luego mediante el método 'add' añadimos componentes al final:
        lista.add("juan");
        lista.add("Luis");
        lista.add("Carlos");
        //tambien se pùede añadir a una posicion en concreto y el resto se muevo
        lista.add(2,"Sebas");
        
        //Para eliminar un nodo de la lista debemos llamar al método 'remove' y pasar la posición del nodo a eliminar:
        lista.remove(0);
        
        //También podemos eliminar los elementos que coinciden con cierta información:
        lista.remove("Carlos");
        
        //La cantidad de elementos nos lo suministra el método 'size':
        System.out.println("Cantidad de elementos en la lista:" + lista.size());

        //Para conocer si la lista almacena cierto valor disponemos del método 'contains':
        if (lista.contains("ana"))
            System.out.println("El nombre 'ana' si esta almacenado en la lista");
        else
            System.out.println("El nombre 'ana' no esta almacenado en la lista");
        
        //Para recuperar el dato de un nodo sin eliminarlo podemos hace uso del método 'get' 
        //(en un ArrayList este método es muy rápido y no depende de la cantidad de elementos):
        System.out.println("El segundo elemento de la lista es:" + lista.get(1));
        
        //Eliminamos todos los nodos de la lista mediante el método 'clear':
        lista.clear();
        
        //Podemos consultar si la lista se encuentra vacía mediante el método 'isEmpty':¡
        if (lista.isEmpty())
            System.out.println("La lista se encuentra vacía");
        
        //PILA / STACK
        Stack <String> pila = new Stack<>();  
        //Para agregar elementos en la pila lo hacemos a través del método push:
        pila.push("primero");
        pila.push("segundo");
        pila.push("tercero");
        pila.push("cuarto");
        pila.push("quinto");
        
        //Para conocer la cantidad de elementos almacenados en la pila llamamos al método size:
        System.out.println("Cantidad de elementos en la pila:" + pila.size());
        
        //Para retirar un elementos de la pila disponemos del método pop: (ademas devuelve el elemneto retirado)
        System.out.println("Extraemos un elemento de la pila:" + pila.pop());
        
        //En cambio si queremos conocer el valor que hay en el primer elemento(cima) de la pila pero sin eliminarlo hacemos uso del método peek:
        System.out.println("Consultamos el primer elemento de la pila sin extraerlo:" + pila.peek());
        
        //Para saber si la lista esta vacia tenemos el método isEmpty (true si esta vacia , false si no)
        while (!pila.isEmpty())
            System.out.print(pila.pop() + " - ");
        
        //para vaciar la pila
        //pila.clear(); como la pila ya estaba vacia pues no va a hacer nada 
        
        
        //Colas / Queues
        
        //La diferencia con respecto a la administración de pilas en Java
        //es que para trabajar con colas debemos crear un objeto de la clase LinkedList e implementar la interfaz Queue:
        Queue<Integer> cola = new LinkedList<>();
        //Añadimos elementos al final de la cola mediante el método 'add':
        cola.add(1);
        cola.add(2);
        cola.add(3);
        cola.add(4);
        
        //Para conocer la cantidad disponemos del método size():
        System.out.println("Cantidad de elementos en la cola:" + cola.size());
        
        //Para extraer el nodo de principio de la lista tipo cola lo hacemos mediante el método 'poll': (devolviendo el item)
        System.out.println("Extraemos un elemento de la cola:" + cola.poll());
        
        //i queremos conocer el objeto primero de la cola sin extraerlo lo hacemos mediante el método 'peek':
        System.out.println("Consultamos el primer elemento de la cola sin extraerlo:" + cola.peek());
        
        //Para conocer si la cola se encuentra vacía llamamos al método 'isEmpty':
        while (!cola.isEmpty())
            System.out.print(cola.poll() + "-");
        
        //Para eliminar todos los elementos de una pila empleamos el método clear:
        //cola.clear();*/
        
        //tablas (Map)
         Map<String, String> mapa1 = new HashMap<String, String>();
        
        //Mediante el método put agregamos un elemento a la colección de tipo HashMap: 
        mapa1.put("rojo", "red");
        mapa1.put("verde", "green");
        mapa1.put("azul", "blue");
        mapa1.put("blanco", "white");
        
        //Para imprimir todos los valores del mapa lo recorremos mediante un for:
        for (String valor : mapa1.values())
            System.out.print(valor + "-");
        
        System.out.println("");
        
        //De forma similar si queremos recorrer todas las claves del mapa:
        for (String clave : mapa1.keySet())
            System.out.print(clave + "-");
        
        System.out.println("");
        //Para recuperar un valor para una determinada clave llamamos al método 'get' 
        //y le pasamos la clave a buscar, si dicha clave no existe en el mapa se nos retorna el valor 'null':
        System.out.println("La traducción de 'rojo' es:" + mapa1.get("rojo"));
        
        //Si queremos verificar si una determinada clave existe en el mapa lo hacemos mediante el método 'containsKey':
        if (mapa1.containsKey("negro"))
            System.out.println("No existe la clave 'negro'");
        
        //Para eliminar un elemento de la colección debemos hacer uso del método 'remove', pasamos una clave del mapa:
        mapa1.remove("rojo");
        
        //Para imprimir el mapa completo en la Consola podemos hacer uso del método 'println':
        System.out.println(mapa1);
    }
}

