/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.t3_p_hi_juan_portilla.Preguntas;

import java.util.Scanner;
import java.util.*;

/**
 *
 * @author 34632
 */
public class Preguntas {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        
        int posicion=0, acierto=1 ;
        float fallo=0.5f, puntos = 0f;
        String yo, pregunta ,respuesta;
        
        ArrayList<String> preguntasRespuestas = new ArrayList<>(); //todas las preguntas y respuestas
        ArrayList<Integer> aleatorio = new ArrayList<>(); //indice
        
        try {
            
            Scanner sc = new Scanner(Preguntas.class.getResourceAsStream("preguntsaYRespuestas.txt"));
            Scanner lc = new Scanner(System.in);
            
            //traspasar los datos de preguntsaYRespuestas.txt a la lista pr
            while (sc.hasNext()){
                //añado las pregunats y respuestas a pr
                preguntasRespuestas.add(sc.nextLine());
                
                if(posicion%2 == 0)
                    aleatorio.add(posicion);  
                
                posicion++;
            }

            //remuevo la pòsicion de las preguntas
            Collections.shuffle(aleatorio);
    
            //lo convierto en iterator para ecorrerlo mas facil
            Iterator <Integer> preguntasAleatorias = aleatorio.iterator();
            
            //mientras haya preguntas
            while(preguntasAleatorias.hasNext()){
                //para no tener que escribir mas y que el codigo quede mas limpio reutilizo esta variable
                posicion=preguntasAleatorias.next();
                        
                //saca las preguntas aleatoriamente
                pregunta = preguntasRespuestas.get(posicion);
                respuesta = preguntasRespuestas.get(posicion + 1);
                //la convierto a mayusculas
                System.out.println(pregunta);
                yo = lc.nextLine();
                
                if(yo.equalsIgnoreCase(respuesta)){
                    System.out.println("Correctoo!!! -> +"+acierto+"\n");
                    puntos += acierto;
                }else{
                    System.out.println("falaste.... -> -"+fallo+"\n");
                    puntos -= fallo;
                }
            }
            
            System.out.println("puntos totales :"+puntos);
            
            if(puntos >= 5)
                System.out.println("Aprobasteeee");
            else
                System.out.println("Suspendiste mi pana");

            sc.close();
            lc.close();
            
        } catch (NullPointerException ne) {
            System.out.println("No se encontro el archivo. Erorr: "+ne);
        }catch (Exception e){
            System.out.println(e);
        }
        
        

        
    }  
}
