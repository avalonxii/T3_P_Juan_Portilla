/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.t3_p_hi_juan_portilla.herencia;

/**
 *
 * @author 34632
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Padre padre = new Padre("santa","claus");
        Hijo hijo = new Hijo(22,"juan","portilla"); //comparten atributos
        
        padre.saludar(); //metodo saludar de padre
        hijo.saludar();// estamos llamdo al metodo sobreescrito de hijo
        hijo.saludar("pedro",22);
        hijo.saludar(12, "jjjj");
        
    }
    
}
