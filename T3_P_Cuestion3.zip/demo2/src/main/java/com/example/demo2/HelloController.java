package com.example.demo2;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class HelloController {
    Conexion connect= new Conexion();

    private int key;
    @FXML
    private TextField txtNombre, txtUnidades, txtPrecio ;

    @FXML
    private DatePicker pickerFecha;

    @FXML
    private CheckBox checkDisponible;

    @FXML
    private Button btnRefresh, btnActualizar, btnDeshacer, btnAdd;

    @FXML
    private Label lblMessage;

    @FXML private TableView <Product> tableProductos;
    @FXML private TableColumn<Product,Integer> colidProducto;
    @FXML private TableColumn<Product,String> colNombre;
    @FXML private TableColumn<Product,Date> colFechaEnvasado;
    @FXML private TableColumn<Product,Integer> colUnidades;
    @FXML private TableColumn<Product,Double> colPrecio;
    @FXML private TableColumn<Product,Boolean> colDisponible;




    @FXML
    protected void add() {

        //Se conecta a la base de datos
        this.connect.conectar();

        //parsea algunos campos necesarios
        Date date = Date.from(pickerFecha.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        int unidades = Integer.parseInt(txtUnidades.getText());
        double precio =  Double.parseDouble(txtPrecio.getText());

        // extrae los elementos de los TextFields y crea un objeto producto para luego insertarlo
        Product producto = new Product(txtNombre.getText(), date, unidades, precio, checkDisponible.isSelected());
        this.connect.insertar(producto); //inserta el producto

        //Refresca la tabla para mostrar la nueva fila añadida
        Refresh();

        //cierra conexion
        this.connect.cerrar();

        // reestablece los campos
        undo();
    }

    @FXML
    protected void Refresh(){

        this.connect.conectar();
        this.connect.RecogerDatos();

        this.colidProducto.setCellValueFactory(new PropertyValueFactory<Product,Integer>("idProducto"));
        this.colNombre.setCellValueFactory(new PropertyValueFactory<Product,String>("nombre"));
        this.colFechaEnvasado.setCellValueFactory(new PropertyValueFactory<Product,Date>("fechaEnvasado"));
        this.colUnidades.setCellValueFactory(new PropertyValueFactory<Product,Integer>("unidades"));
        this.colPrecio.setCellValueFactory(new PropertyValueFactory<Product,Double>("precio"));
        this.colDisponible.setCellValueFactory(new PropertyValueFactory<Product,Boolean>("disponible"));

        if(this.tableProductos.getColumns().size() < 7){
            addButtonDelete();
            addButtonUpdateView();
        }

        this.tableProductos.setItems(this.connect.productos);


        btnRefresh.setDisable(true);
        btnRefresh.setVisible(false);
    }

    private void addButtonDelete() {
        TableColumn<Product, Void> colBtn = new TableColumn("");
        Callback<TableColumn<Product, Void>, TableCell<Product, Void>> cellFactory = new Callback<TableColumn<Product, Void>, TableCell<Product, Void>>() {

            //Creamos boton delete y lo añadimos al la tabla
            @Override
            public TableCell<Product, Void> call(final TableColumn<Product, Void> param) {
                final TableCell<Product, Void> cell = new TableCell<Product, Void>() {

                    private final Button btn = new Button("Delete");
                    {
                        //añadimos un poco de estilo
                        btn.setStyle("-fx-background-color: #EE5A5A; -fx-pref-width: 200px;");
                        //añadimos el evento Delete
                        btn.setOnAction((ActionEvent event) -> {

                            //el propio boton recoge a que producto nos referimos
                            Product data = getTableView().getItems().get(getIndex());

                            //Creamos un objeto de tipo conexion y conetamos con la base de datos
                            Conexion c= new Conexion();
                            c.conectar();

                            //introduce el idProducto para luego buscarlo en la base datos y eliminarlo
                            c.delete(data.getIdProducto());

                            //cerramos conexion
                            c.cerrar();

                            //refrescamos tabla
                            Refresh();
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };

        colBtn.setPrefWidth(65.0);
        colBtn.setCellFactory(cellFactory);
        tableProductos.getColumns().add(colBtn);
    }

    private void addButtonUpdateView() {
        TableColumn<Product, Void> colBtn = new TableColumn("");

        Callback<TableColumn<Product, Void>, TableCell<Product, Void>> cellFactory = new Callback<TableColumn<Product, Void>, TableCell<Product, Void>>() {

            @Override
            public TableCell<Product, Void> call(final TableColumn<Product, Void> param) {
                final TableCell<Product, Void> cell = new TableCell<Product, Void>() {

                    //creamos boton Update y lo añadimos a la tabla
                    private final Button btn = new Button("Update");
                    {
                        //le ponemkos un poco de estilo
                        btn.setStyle("-fx-background-color: #5ACFEE; -fx-pref-width: 200px;");
                        //añadimos el evento UpdateView
                        btn.setOnAction((ActionEvent event) -> {

                            //deshabilitar el boton de Añadir
                            btnAdd.setDisable(true);
                            btnAdd.setVisible(false);

                            //habilita los botones de deshacer y actualizar
                            btnActualizar.setDisable(false);
                            btnActualizar.setVisible(true);
                            btnActualizar.setOpacity(1);

                            btnDeshacer.setDisable(false);
                            btnDeshacer.setVisible(true);
                            btnDeshacer.setOpacity(1);

                            //habilita la label para avisar que estas en el modo actualizar
                            lblMessage.setDisable(false);
                            lblMessage.setText(" -- ACTUALIZANDO --");

                            //el propio boton recoge a que producto nos referimos
                            Product data = getTableView().getItems().get(getIndex());

                            //rellena los campos de la isquierda
                            visualizarUpdate(data);
                        });
                    }

                    @Override
                    public void updateItem(Void item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty) {
                            setGraphic(null);
                        } else {
                            setGraphic(btn);
                        }
                    }
                };
                return cell;
            }
        };

        colBtn.setPrefWidth(65.0);
        colBtn.setCellFactory(cellFactory);
        tableProductos.getColumns().add(colBtn);
    }

    private void visualizarUpdate(Product pView){
        String dateParse= pView.getFechaEnvasado()+"";

        txtNombre.setText(pView.getNombre());
        pickerFecha.setValue(LocalDate.parse(dateParse));
        txtUnidades.setText(pView.getUnidades()+"");
        txtPrecio.setText(pView.getPrecio()+"");
        checkDisponible.setSelected(pView.getDisponible());


        this.key=pView.getIdProducto();
    }

    @FXML
    protected void update(){

        //se parsean algunos campos
        Date date = Date.from(pickerFecha.getValue().atStartOfDay(ZoneId.systemDefault()).toInstant());
        int unidades = Integer.parseInt(txtUnidades.getText());
        double precio =  Double.parseDouble(txtPrecio.getText());

        //creamos producto para actualizar
        Product p = new Product(this.key,txtNombre.getText(), date, unidades, precio, checkDisponible.isSelected());

        //conectamos a la base de datos
        this.connect.conectar();

        //pasa como parametro los datos del producto a actualizar
        this.connect.Update(p);

        //cerramos conexion
        this.connect.cerrar();

        //refrescamos y restablecmos campos
        Refresh();
        undo();
    }

    @FXML
    protected void undo() {
        txtNombre.setText(null);
        pickerFecha.setValue(null);
        txtUnidades.setText(null);
        txtPrecio.setText(null);
        checkDisponible.setSelected(false);

        btnAdd.setDisable(false);
        btnAdd.setVisible(true);

        btnActualizar.setDisable(true);
        btnActualizar.setVisible(false);

        btnDeshacer.setDisable(true);
        btnDeshacer.setVisible(false);

        lblMessage.setDisable(true);
        lblMessage.setVisible(false);
    }

}

