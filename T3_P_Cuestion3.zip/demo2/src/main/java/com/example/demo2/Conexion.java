package com.example.demo2;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;


public class Conexion {
    Connection conn=null;

    ObservableList<Product> productos = FXCollections.observableArrayList();

    public void conectar(){
        try {
            //CONEXION A LA BASE DE DATOS USUARIOS
            //Class.forName("com.mysql.jdbc.Driver");
                //System.out.println("conector correcto");

            String url="jdbc:mysql://localhost:3306/test";
            String user="root";
            String password="";
            this.conn = DriverManager.getConnection(url, user, password);
                //System.out.println("la conexión es: "+this.conn.toString());

        }/* catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
            //e.printStackTrace();
        } */catch (SQLException e) {
            System.out.println("EROR: "+e.getMessage());
            e.printStackTrace();
        }
    }

    public void insertar(Product p){
        //try catch para capturar una excepcion Sql con un mensaje personalizados
        try {
            //parseamos campo java.util.date a java.sql.date
            Date sqlDate =  new java.sql.Date(p.getFechaEnvasado().getTime());

            //CONSULTA Insert
            String consulta="INSERT INTO `productos` VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement  st =this.conn.prepareStatement(consulta);

            //los parametros(?) de la consulta insert
            st.setString (1,null);
            st.setString (2, p.getNombre());
            st.setDate   (3, sqlDate);
            st.setInt    (4, p.getUnidades());
            st.setDouble (5, p.getPrecio());
            st.setBoolean(6, p.getDisponible());

            //Ejecutamos setencia
            st.execute();

        }catch (SQLException e) {
            System.out.println("HA FALLADO EN HACER LA CONSULTA insertar");
            e.printStackTrace();
        }
    }

    public void RecogerDatos(){
        try {
            productos.clear();

            String consulta="SELECT * FROM productos";
            Statement st = this.conn.createStatement();
            ResultSet rs = st.executeQuery(consulta);

            while (rs.next()){
                this.productos.add(new Product(rs.getInt (1),rs.getString(2), rs.getDate (3), rs.getInt (4),rs.getDouble(5) ,rs.getBoolean(6)));
            }

        }catch (SQLException e) {
            System.out.println("HA FALLADO EN HACER LA CONSULTA Mostrar");
            e.printStackTrace();
        }
    }

    public  void delete(int id){
        try {
            //CONSULTA delete
            String consultaDelete="DELETE FROM `productos` WHERE `productos`.`idProducto` = ?";
            PreparedStatement st = this.conn.prepareStatement(consultaDelete);
            st.setInt       (1,id);

            st.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public  void Update(Product p){
        try {

            Date sqlDate =  new java.sql.Date(p.getFechaEnvasado().getTime());

            //CONSULTA      updates
            String consultaUpdate = "UPDATE `productos` SET  `nombre` = ?, `fechaEnvasado` = ?, `unidades` = ?, `precio` = ?, `disponible` = ? WHERE `productos`.`idProducto` = ?";
            PreparedStatement st = this.conn.prepareStatement(consultaUpdate);

            st.setString (1, p.getNombre());
            st.setDate   (2, sqlDate);
            st.setInt    (3, p.getUnidades());
            st.setDouble (4, p.getPrecio());
            st.setBoolean(5, p.getDisponible());
            st.setInt    (6, p.getIdProducto());

            st.execute();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void cerrar(){
        try {

            this.conn.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
